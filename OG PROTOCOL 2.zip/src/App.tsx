import { Shield } from "lucide-react";
import { useState } from "react";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { StatsTable } from "./components/stats-table";
import logo from "figma:asset/8a8f08cd6ce5dde7016dc17af20bd47b17a5eb4e.png";

export default function App() {
  return (
    <div className="min-h-screen relative">
      {/* Gradient Background */}
      <div className="fixed inset-0 bg-gradient-to-br from-[#0a1628] via-[#000000] via-50% to-[#0a1628] -z-10" />
      
      {/* Grid Pattern Overlay */}
      <div 
        className="fixed inset-0 -z-10 opacity-40"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(59, 130, 246, 0.15) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(59, 130, 246, 0.15) 1px, transparent 1px)
          `,
          backgroundSize: '80px 80px'
        }}
      />
      
      {/* Header */}
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="border-b border-gray-800/50 bg-[#0a0e27]/80 backdrop-blur-sm"
      >
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <img src={logo} alt="OG Protocol" className="w-8 h-8" />
              <span className="text-white font-bold">OG Protocol</span>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                Inicio
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                Producto
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                ¿Cómo funciona?
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                Estadísticas
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                Nuestro equipo
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                Contacto
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition-colors">
                FAQ
              </a>
            </nav>

            {/* CTA Button */}
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded transition-colors">
              Comenzar
            </button>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="max-w-7xl mx-auto">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
            className="text-white text-center mb-8 text-3xl font-bold"
          >
            Estadísticas de Jugadores
          </motion.h1>
          
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
          >
            <StatsTable />
          </motion.div>
        </div>
      </main>
    </div>
  );
}