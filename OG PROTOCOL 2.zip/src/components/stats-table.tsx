import { useState } from "react";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";

interface PlayerStats {
  rank: number;
  avatar: string;
  badge: "MVP++" | "MVP+" | "YOUTUBER" | "MVP";
  name: string;
  wins: string;
  level: number;
  finalKills: string;
}

const mockPlayers: PlayerStats[] = [
  {
    rank: 1,
    avatar: "🎮",
    badge: "MVP++",
    name: "WarOG_DAWN",
    wins: "67,873",
    level: 6384,
    finalKills: "305,789",
  },
  {
    rank: 2,
    avatar: "🎯",
    badge: "MVP++",
    name: "Winks ✦CROSS✦",
    wins: "64,760",
    level: 3292,
    finalKills: "258,233",
  },
  {
    rank: 3,
    avatar: "⚔️",
    badge: "MVP++",
    name: "lolitzpanda_LELITZ",
    wins: "64,175",
    level: 3409,
    finalKills: "235,239",
  },
  {
    rank: 4,
    avatar: "🏆",
    badge: "MVP++",
    name: "RRG_ DEFEAT✦",
    wins: "51,268",
    level: 2672,
    finalKills: "156,423",
  },
  {
    rank: 5,
    avatar: "👑",
    badge: "YOUTUBER",
    name: "Manhal_IQ_ ✦ABYSS✦",
    wins: "50,679",
    level: 3887,
    finalKills: "219,564",
  },
  {
    rank: 6,
    avatar: "🎲",
    badge: "MVP++",
    name: "Josie ❀FAKE❤",
    wins: "46,946",
    level: 3039,
    finalKills: "139,044",
  },
  {
    rank: 7,
    avatar: "🎪",
    badge: "MVP++",
    name: "tilings ✦CROSS✦",
    wins: "46,655",
    level: 3600,
    finalKills: "209,059",
  },
  {
    rank: 8,
    avatar: "🎨",
    badge: "MVP+",
    name: "SixtoTheGreat ❀BLOSS❀",
    wins: "45,866",
    level: 2736,
    finalKills: "106,806",
  },
  {
    rank: 9,
    avatar: "🌟",
    badge: "MVP++",
    name: "Hashito ✦STAR✦",
    wins: "44,242",
    level: 3017,
    finalKills: "179,531",
  },
  {
    rank: 10,
    avatar: "🔥",
    badge: "MVP++",
    name: "_JBC_ ❀FAKE❤",
    wins: "44,082",
    level: 3114,
    finalKills: "204,970",
  },
  {
    rank: 11,
    avatar: "⚡",
    badge: "MVP++",
    name: "Andorite ✦XL✦",
    wins: "42,787",
    level: 1662,
    finalKills: "104,973",
  },
  {
    rank: 12,
    avatar: "🎭",
    badge: "YOUTUBER",
    name: "NoSDaemon ❀FAKE❤",
    wins: "42,749",
    level: 3702,
    finalKills: "187,496",
  },
  {
    rank: 13,
    avatar: "💎",
    badge: "MVP+",
    name: "xLectroLightnin O🔥T",
    wins: "42,491",
    level: 2603,
    finalKills: "89,794",
  },
  {
    rank: 14,
    avatar: "🌈",
    badge: "MVP++",
    name: "tilingsson ✦CROSS✦",
    wins: "41,789",
    level: 3085,
    finalKills: "193,211",
  },
];

const getBadgeColor = (badge: string) => {
  switch (badge) {
    case "MVP++":
      return "bg-gradient-to-r from-yellow-500 to-orange-500";
    case "MVP+":
      return "bg-cyan-500";
    case "YOUTUBER":
      return "bg-red-600";
    case "MVP":
      return "bg-blue-500";
    default:
      return "bg-gray-500";
  }
};

const getLevelColor = (level: number) => {
  if (level >= 4000) return "text-purple-400";
  if (level >= 3000) return "text-blue-400";
  if (level >= 2000) return "text-green-400";
  if (level >= 1000) return "text-yellow-400";
  return "text-gray-400";
};

export function StatsTable() {
  const [timeFilter, setTimeFilter] = useState("alltime");
  const [gameMode, setGameMode] = useState("overall");

  return (
    <div className="bg-[#0a0e27]/60 backdrop-blur-sm rounded-lg border border-gray-800/50 p-6">
      {/* Time Filter */}
      <div className="flex gap-4 mb-6 border-b border-gray-700/30 pb-4">
        <button className="text-blue-400 border-b-2 border-blue-400 pb-2 px-4">
          Kills
        </button>
      </div>

      {/* Game Mode Filter */}
      {/* Stats Table */}
      <div className="rounded-lg overflow-hidden border border-gray-700/30">
        <Table>
          <TableHeader>
            <TableRow className="border-gray-700/50 bg-gray-800/30 hover:bg-gray-800/30">
              <TableHead className="text-gray-400">Jugador</TableHead>
              <TableHead className="text-center text-gray-400">Kills</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockPlayers.map((player, index) => (
              <motion.tr
                key={player.rank}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.4, 
                  delay: 0.6 + (index * 0.05),
                  ease: "easeOut" 
                }}
                className="border-gray-700/50 hover:bg-gray-800/30"
              >
                <TableCell>
                  <div className="flex items-center gap-3">
                    <span className="text-gray-400 w-8">{player.rank}.</span>
                    <div className="flex items-center gap-3 flex-1">
                      <span className="text-gray-300">{player.name}</span>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-center text-gray-300">
                  {player.finalKills}
                </TableCell>
              </motion.tr>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}