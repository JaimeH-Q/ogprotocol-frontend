
  # OG PROTOCOL 2

  This is a code bundle for OG PROTOCOL 2. The original project is available at https://www.figma.com/design/QJHUOGaUNuvGHPOrVOLWtk/OG-PROTOCOL-2.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  